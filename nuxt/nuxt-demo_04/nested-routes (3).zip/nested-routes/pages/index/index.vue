<template>
  <h2>Please select an user.</h2>
</template>

<script>
export default {
  head: {
    title: 'Please select an user'
  }
}
</script>

<style scoped>
h2 {
  text-align: center;
  margin-top: 100px;
  font-family: sans-serif;
}
</style>
